#include <stdio.h>
int main() {
    printf("%I64d", (long long int)0);
}
