#include <stdio.h>
int main() {
    printf("%lld", (long long int)0);
}
